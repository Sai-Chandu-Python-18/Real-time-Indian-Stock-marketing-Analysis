import { useState, useEffect } from 'react';

interface StockDataPoint {
  time: string;
  price: number;
  volume: number;
}

export function useStockData(symbol: string, timeframe: string) {
  const [stockData, setStockData] = useState<StockDataPoint[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchStockData = async () => {
      setIsLoading(true);
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Generate mock data based on timeframe
      const generateMockData = () => {
        const dataPoints = timeframe === '1D' ? 24 : timeframe === '5D' ? 120 : 252;
        const basePrice = Math.random() * 1000 + 500; // Random base price between 500-1500
        
        return Array.from({ length: dataPoints }, (_, i) => {
          const variation = (Math.random() - 0.5) * 20; // ±10 price variation
          const trend = Math.sin(i / 10) * 5; // Add some trend
          
          return {
            time: timeframe === '1D' 
              ? `${String(9 + Math.floor(i / 4)).padStart(2, '0')}:${String((i % 4) * 15).padStart(2, '0')}`
              : new Date(Date.now() - (dataPoints - i) * 24 * 60 * 60 * 1000).toLocaleDateString(),
            price: basePrice + variation + trend + (i * 0.1),
            volume: Math.floor(Math.random() * 1000000) + 100000
          };
        });
      };

      setStockData(generateMockData());
      setIsLoading(false);
    };

    fetchStockData();
  }, [symbol, timeframe]);

  return { stockData, isLoading };
}