import { useState } from 'react';

interface BacktestResult {
  totalReturn: number;
  sharpeRatio: number;
  maxDrawdown: number;
  winRate: number;
  equityCurve: Array<{
    date: string;
    portfolio: number;
    benchmark: number;
  }>;
}

export function useBacktest() {
  const [backtestResult, setBacktestResult] = useState<BacktestResult | null>(null);
  const [isRunning, setIsRunning] = useState(false);

  const runBacktest = async (
    symbol: string,
    strategy: string,
    parameters: any
  ) => {
    setIsRunning(true);
    
    // Simulate backtest computation
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Generate mock backtest results
    const generateEquityCurve = () => {
      const days = 252; // 1 year of trading days
      const initialValue = parameters.initialCapital;
      let portfolioValue = initialValue;
      let benchmarkValue = initialValue;
      
      return Array.from({ length: days }, (_, i) => {
        // Simulate strategy performance with some randomness
        const strategyReturn = (Math.random() - 0.45) * 0.02; // Slight positive bias
        const benchmarkReturn = (Math.random() - 0.48) * 0.015; // Market return
        
        portfolioValue *= (1 + strategyReturn);
        benchmarkValue *= (1 + benchmarkReturn);
        
        return {
          date: new Date(Date.now() - (days - i) * 24 * 60 * 60 * 1000).toLocaleDateString(),
          portfolio: portfolioValue,
          benchmark: benchmarkValue
        };
      });
    };

    const equityCurve = generateEquityCurve();
    const finalPortfolioValue = equityCurve[equityCurve.length - 1].portfolio;
    const finalBenchmarkValue = equityCurve[equityCurve.length - 1].benchmark;
    
    const totalReturn = ((finalPortfolioValue - parameters.initialCapital) / parameters.initialCapital) * 100;
    const benchmarkReturn = ((finalBenchmarkValue - parameters.initialCapital) / parameters.initialCapital) * 100;
    
    // Calculate max drawdown
    let maxDrawdown = 0;
    let peak = parameters.initialCapital;
    
    equityCurve.forEach(point => {
      if (point.portfolio > peak) {
        peak = point.portfolio;
      }
      const drawdown = ((peak - point.portfolio) / peak) * 100;
      if (drawdown > maxDrawdown) {
        maxDrawdown = drawdown;
      }
    });

    const result: BacktestResult = {
      totalReturn,
      sharpeRatio: totalReturn / Math.max(Math.sqrt(252) * 0.15, 0.01), // Simplified Sharpe ratio
      maxDrawdown,
      winRate: 55 + Math.random() * 20, // Random win rate between 55-75%
      equityCurve
    };

    setBacktestResult(result);
    setIsRunning(false);
  };

  return { backtestResult, isRunning, runBacktest };
}