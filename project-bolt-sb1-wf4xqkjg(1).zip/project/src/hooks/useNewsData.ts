import { useState, useEffect } from 'react';

interface NewsItem {
  id: string;
  title: string;
  description: string;
  url: string;
  source: string;
  publishedAt: string;
  sentiment: 'positive' | 'negative' | 'neutral';
  image?: string;
  readTime: number;
}

export function useNewsData(symbol: string) {
  const [news, setNews] = useState<NewsItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchNews = async () => {
      setIsLoading(true);
      
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Generate mock news data
      const mockNews: NewsItem[] = [
        {
          id: '1',
          title: `${symbol} Reports Strong Q3 Results, Beats Estimates`,
          description: `${symbol} has announced impressive quarterly results, surpassing analyst expectations with strong revenue growth and improved margins.`,
          url: '#',
          source: 'Economic Times',
          publishedAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
          sentiment: 'positive',
          image: 'https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=400',
          readTime: 3
        },
        {
          id: '2',
          title: `Market Volatility Affects ${symbol} Trading Volume`,
          description: 'Recent market fluctuations have led to increased trading activity and price volatility in the stock.',
          url: '#',
          source: 'Business Standard',
          publishedAt: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
          sentiment: 'neutral',
          image: 'https://images.pexels.com/photos/159888/pexels-photo-159888.jpeg?auto=compress&cs=tinysrgb&w=400',
          readTime: 2
        },
        {
          id: '3',
          title: `Analysts Upgrade ${symbol} Rating to Buy`,
          description: 'Leading brokerage firms have upgraded their rating for the stock citing strong fundamentals and growth prospects.',
          url: '#',
          source: 'Moneycontrol',
          publishedAt: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
          sentiment: 'positive',
          image: 'https://images.pexels.com/photos/186461/pexels-photo-186461.jpeg?auto=compress&cs=tinysrgb&w=400',
          readTime: 4
        },
        {
          id: '4',
          title: `${symbol} Faces Regulatory Challenges in New Sector`,
          description: 'The company is navigating new regulatory requirements that may impact its expansion plans in the sector.',
          url: '#',
          source: 'Financial Express',
          publishedAt: new Date(Date.now() - 8 * 60 * 60 * 1000).toISOString(),
          sentiment: 'negative',
          image: 'https://images.pexels.com/photos/534216/pexels-photo-534216.jpeg?auto=compress&cs=tinysrgb&w=400',
          readTime: 5
        }
      ];

      setNews(mockNews);
      setIsLoading(false);
    };

    fetchNews();
  }, [symbol]);

  return { news, isLoading };
}