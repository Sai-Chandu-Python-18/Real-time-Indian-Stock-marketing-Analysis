import { useState, useEffect } from 'react';

interface StockMetrics {
  currentPrice: number;
  dayChange: number;
  dayChangePercent: number;
  volume: number;
  volumeChange: number;
  volumeChangePercent: number;
  dayHigh: number;
  dayLow: number;
  marketCap: number;
  pe: number;
}

export function useStockMetrics(symbol: string) {
  const [metrics, setMetrics] = useState<StockMetrics>({
    currentPrice: 0,
    dayChange: 0,
    dayChangePercent: 0,
    volume: 0,
    volumeChange: 0,
    volumeChangePercent: 0,
    dayHigh: 0,
    dayLow: 0,
    marketCap: 0,
    pe: 0
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchMetrics = async () => {
      setIsLoading(true);
      
      await new Promise(resolve => setTimeout(resolve, 600));
      
      // Generate realistic metrics based on symbol
      const basePrice = symbol === 'RELIANCE' ? 2500 : 
                       symbol === 'TCS' ? 3200 :
                       symbol === 'INFY' ? 1400 :
                       Math.random() * 2000 + 500;
      
      const dayChange = (Math.random() - 0.5) * 100;
      const volume = Math.floor(Math.random() * 10000000) + 1000000;
      
      setMetrics({
        currentPrice: basePrice + dayChange,
        dayChange,
        dayChangePercent: (dayChange / basePrice) * 100,
        volume,
        volumeChange: (Math.random() - 0.5) * 2000000,
        volumeChangePercent: (Math.random() - 0.5) * 50,
        dayHigh: basePrice + dayChange + Math.random() * 50,
        dayLow: basePrice + dayChange - Math.random() * 50,
        marketCap: Math.floor(Math.random() * 500000) + 100000,
        pe: Math.random() * 30 + 10
      });
      
      setIsLoading(false);
    };

    fetchMetrics();
    
    // Update every 10 seconds
    const interval = setInterval(fetchMetrics, 10000);
    
    return () => clearInterval(interval);
  }, [symbol]);

  return { metrics, isLoading };
}