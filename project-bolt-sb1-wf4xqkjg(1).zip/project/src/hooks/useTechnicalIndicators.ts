import { useState, useEffect } from 'react';

interface TechnicalIndicators {
  rsi: { value: number; signal: string };
  macd: { macd: number; signal_line: number; histogram: number; signal: string };
  bollinger: { upper: number; middle: number; lower: number; signal: string };
  sma20: number;
  sma50: number;
  ema20: number;
  ema50: number;
}

export function useTechnicalIndicators(symbol: string) {
  const [indicators, setIndicators] = useState<TechnicalIndicators>({
    rsi: { value: 50, signal: 'NEUTRAL' },
    macd: { macd: 0, signal_line: 0, histogram: 0, signal: 'NEUTRAL' },
    bollinger: { upper: 0, middle: 0, lower: 0, signal: 'NEUTRAL' },
    sma20: 0,
    sma50: 0,
    ema20: 0,
    ema50: 0
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchIndicators = async () => {
      setIsLoading(true);
      
      await new Promise(resolve => setTimeout(resolve, 700));
      
      // Generate realistic technical indicators
      const basePrice = Math.random() * 2000 + 500;
      const rsiValue = Math.random() * 100;
      const macdValue = (Math.random() - 0.5) * 20;
      const signalLine = (Math.random() - 0.5) * 15;
      
      setIndicators({
        rsi: {
          value: rsiValue,
          signal: rsiValue > 70 ? 'SELL' : rsiValue < 30 ? 'BUY' : 'NEUTRAL'
        },
        macd: {
          macd: macdValue,
          signal_line: signalLine,
          histogram: macdValue - signalLine,
          signal: macdValue > signalLine ? 'BUY' : 'SELL'
        },
        bollinger: {
          upper: basePrice + 50,
          middle: basePrice,
          lower: basePrice - 50,
          signal: Math.random() > 0.5 ? 'BUY' : 'SELL'
        },
        sma20: basePrice - Math.random() * 20,
        sma50: basePrice - Math.random() * 50,
        ema20: basePrice - Math.random() * 15,
        ema50: basePrice - Math.random() * 40
      });
      
      setIsLoading(false);
    };

    fetchIndicators();
    
    // Update every 15 seconds
    const interval = setInterval(fetchIndicators, 15000);
    
    return () => clearInterval(interval);
  }, [symbol]);

  return { indicators, isLoading };
}