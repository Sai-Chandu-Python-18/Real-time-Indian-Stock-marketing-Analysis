import { useState, useEffect } from 'react';

interface MarketData {
  nifty: { value: number; change: number; changePercent: number };
  sensex: { value: number; change: number; changePercent: number };
  bankNifty: { value: number; change: number; changePercent: number };
}

export function useMarketData() {
  const [marketData, setMarketData] = useState<MarketData>({
    nifty: { value: 19674.25, change: 125.30, changePercent: 0.64 },
    sensex: { value: 65953.48, change: 418.72, changePercent: 0.64 },
    bankNifty: { value: 44821.35, change: -89.25, changePercent: -0.20 }
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate API call
    const fetchMarketData = async () => {
      setIsLoading(true);
      
      // Simulate network delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Generate realistic market data with small random variations
      const generateVariation = (base: number, maxChange: number = 50) => {
        const change = (Math.random() - 0.5) * maxChange;
        const changePercent = (change / base) * 100;
        return {
          value: base + change,
          change,
          changePercent
        };
      };

      setMarketData({
        nifty: generateVariation(19674.25, 100),
        sensex: generateVariation(65953.48, 400),
        bankNifty: generateVariation(44821.35, 200)
      });
      
      setIsLoading(false);
    };

    fetchMarketData();
    
    // Update every 30 seconds
    const interval = setInterval(fetchMarketData, 30000);
    
    return () => clearInterval(interval);
  }, []);

  return { marketData, isLoading };
}