import { useState, useEffect } from 'react';

interface VolumeDataPoint {
  time: string;
  volume: number;
}

export function useVolumeData(symbol: string) {
  const [volumeData, setVolumeData] = useState<VolumeDataPoint[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchVolumeData = async () => {
      setIsLoading(true);
      
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Generate mock volume data for the last 20 trading sessions
      const generateVolumeData = () => {
        return Array.from({ length: 20 }, (_, i) => ({
          time: new Date(Date.now() - (19 - i) * 24 * 60 * 60 * 1000).toLocaleDateString(),
          volume: Math.floor(Math.random() * 5000000) + 1000000
        }));
      };

      setVolumeData(generateVolumeData());
      setIsLoading(false);
    };

    fetchVolumeData();
  }, [symbol]);

  return { volumeData, isLoading };
}