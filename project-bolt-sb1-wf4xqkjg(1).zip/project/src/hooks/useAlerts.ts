import { useState, useEffect } from 'react';
import toast from 'react-hot-toast';

interface Alert {
  id: string;
  stock: string;
  type: string;
  condition: string;
  value: number;
  title: string;
  description: string;
  isActive: boolean;
  createdAt: string;
}

export function useAlerts() {
  const [alerts, setAlerts] = useState<Alert[]>([]);

  useEffect(() => {
    // Load alerts from localStorage
    const savedAlerts = localStorage.getItem('stockAlerts');
    if (savedAlerts) {
      setAlerts(JSON.parse(savedAlerts));
    } else {
      // Add some demo alerts
      const demoAlerts: Alert[] = [
        {
          id: '1',
          stock: 'RELIANCE',
          type: 'price',
          condition: 'above',
          value: 2600,
          title: 'RELIANCE Price Alert',
          description: 'Alert when RELIANCE crosses ₹2600',
          isActive: true,
          createdAt: new Date().toISOString()
        },
        {
          id: '2',
          stock: 'TCS',
          type: 'volume',
          condition: 'above',
          value: 5000000,
          title: 'TCS Volume Spike',
          description: 'High volume trading detected',
          isActive: true,
          createdAt: new Date().toISOString()
        }
      ];
      setAlerts(demoAlerts);
      localStorage.setItem('stockAlerts', JSON.stringify(demoAlerts));
    }
  }, []);

  const addAlert = (alert: Alert) => {
    const updatedAlerts = [...alerts, alert];
    setAlerts(updatedAlerts);
    localStorage.setItem('stockAlerts', JSON.stringify(updatedAlerts));
  };

  const removeAlert = (id: string) => {
    const updatedAlerts = alerts.filter(alert => alert.id !== id);
    setAlerts(updatedAlerts);
    localStorage.setItem('stockAlerts', JSON.stringify(updatedAlerts));
    toast.success('Alert removed');
  };

  const toggleAlert = (id: string) => {
    const updatedAlerts = alerts.map(alert =>
      alert.id === id ? { ...alert, isActive: !alert.isActive } : alert
    );
    setAlerts(updatedAlerts);
    localStorage.setItem('stockAlerts', JSON.stringify(updatedAlerts));
  };

  return { alerts, addAlert, removeAlert, toggleAlert };
}