import React, { useState, useEffect } from 'react';
import { Toaster } from 'react-hot-toast';
import { Header } from './components/Header';
import { Dashboard } from './components/Dashboard';
import { StockSearch } from './components/StockSearch';
import { AlertsPanel } from './components/AlertsPanel';
import { NewsPanel } from './components/NewsPanel';
import { BacktestPanel } from './components/BacktestPanel';
import { MarketOverview } from './components/MarketOverview';
import { useMarketData } from './hooks/useMarketData';
import { useAlerts } from './hooks/useAlerts';

type ActiveTab = 'dashboard' | 'alerts' | 'news' | 'backtest';

function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [selectedStock, setSelectedStock] = useState('RELIANCE');
  const { marketData, isLoading } = useMarketData();
  const { alerts } = useAlerts();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <Header 
        activeTab={activeTab} 
        setActiveTab={setActiveTab}
        alertCount={alerts.length}
      />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Market Overview - Always visible */}
        <MarketOverview marketData={marketData} isLoading={isLoading} />
        
        {/* Stock Search */}
        <div className="mb-6">
          <StockSearch 
            selectedStock={selectedStock}
            onStockSelect={setSelectedStock}
          />
        </div>

        {/* Tab Content */}
        {activeTab === 'dashboard' && (
          <Dashboard selectedStock={selectedStock} />
        )}
        
        {activeTab === 'alerts' && (
          <AlertsPanel />
        )}
        
        {activeTab === 'news' && (
          <NewsPanel selectedStock={selectedStock} />
        )}
        
        {activeTab === 'backtest' && (
          <BacktestPanel selectedStock={selectedStock} />
        )}
      </main>

      <Toaster 
        position="top-right"
        toastOptions={{
          duration: 4000,
          style: {
            background: '#363636',
            color: '#fff',
          },
        }}
      />
    </div>
  );
}

export default App;