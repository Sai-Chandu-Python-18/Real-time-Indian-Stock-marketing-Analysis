import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Volume } from 'lucide-react';
import { useVolumeData } from '../hooks/useVolumeData';

interface VolumeAnalysisProps {
  selectedStock: string;
}

export function VolumeAnalysis({ selectedStock }: VolumeAnalysisProps) {
  const { volumeData, isLoading } = useVolumeData(selectedStock);

  if (isLoading) {
    return (
      <div className="bg-white rounded-lg border border-slate-200 p-6">
        <div className="animate-pulse">
          <div className="h-6 bg-slate-200 rounded w-32 mb-4" />
          <div className="h-60 bg-slate-200 rounded" />
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
      <div className="p-4 border-b border-slate-200">
        <div className="flex items-center space-x-2">
          <Volume className="w-5 h-5 text-green-600" />
          <h3 className="text-lg font-semibold text-slate-900">Volume Analysis</h3>
        </div>
      </div>
      
      <div className="p-4">
        <div className="h-60">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={volumeData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis 
                dataKey="time" 
                stroke="#64748b"
                fontSize={12}
              />
              <YAxis 
                stroke="#64748b"
                fontSize={12}
                tickFormatter={(value) => `${(value / 1000000).toFixed(1)}M`}
              />
              <Tooltip 
                contentStyle={{
                  backgroundColor: '#1e293b',
                  border: 'none',
                  borderRadius: '8px',
                  color: '#fff'
                }}
                formatter={(value: number) => [`${(value / 1000000).toFixed(2)}M`, 'Volume']}
              />
              <Bar 
                dataKey="volume" 
                fill="#10b981"
                radius={[2, 2, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}