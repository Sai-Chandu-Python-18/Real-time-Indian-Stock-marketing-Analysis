import React, { useState } from 'react';
import { Search, Star } from 'lucide-react';

interface StockSearchProps {
  selectedStock: string;
  onStockSelect: (stock: string) => void;
}

const popularStocks = [
  'RELIANCE', 'TCS', 'INFY', 'HDFCBANK', 'ICICIBANK', 
  'BHARTIARTL', 'ITC', 'SBIN', 'LT', 'KOTAKBANK'
];

export function StockSearch({ selectedStock, onStockSelect }: StockSearchProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [isOpen, setIsOpen] = useState(false);

  const filteredStocks = popularStocks.filter(stock =>
    stock.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="relative">
      <div className="bg-white rounded-lg border border-slate-200 p-4">
        <div className="flex items-center space-x-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search stocks (e.g., RELIANCE, TCS, INFY)"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onFocus={() => setIsOpen(true)}
              onBlur={() => setTimeout(() => setIsOpen(false), 200)}
              className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
            
            {isOpen && (
              <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-slate-200 rounded-lg shadow-lg z-10 max-h-60 overflow-y-auto">
                {filteredStocks.map((stock) => (
                  <button
                    key={stock}
                    onClick={() => {
                      onStockSelect(stock);
                      setSearchTerm('');
                      setIsOpen(false);
                    }}
                    className={`w-full text-left px-4 py-2 hover:bg-slate-50 transition-colors duration-200 ${
                      selectedStock === stock ? 'bg-blue-50 text-blue-600' : ''
                    }`}
                  >
                    {stock}
                  </button>
                ))}
              </div>
            )}
          </div>
          
          <div className="text-sm text-slate-600">
            Selected: <span className="font-medium text-blue-600">{selectedStock}</span>
          </div>
        </div>
        
        {/* Popular Stocks */}
        <div className="mt-4">
          <div className="flex items-center space-x-2 mb-2">
            <Star className="w-4 h-4 text-yellow-500" />
            <span className="text-sm font-medium text-slate-700">Popular Stocks</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {popularStocks.slice(0, 6).map((stock) => (
              <button
                key={stock}
                onClick={() => onStockSelect(stock)}
                className={`px-3 py-1 text-sm rounded-full border transition-colors duration-200 ${
                  selectedStock === stock
                    ? 'bg-blue-100 border-blue-300 text-blue-700'
                    : 'bg-slate-100 border-slate-300 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {stock}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}