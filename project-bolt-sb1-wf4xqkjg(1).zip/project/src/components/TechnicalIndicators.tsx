import React from 'react';
import { Activity, TrendingUp, BarChart3 } from 'lucide-react';
import { useTechnicalIndicators } from '../hooks/useTechnicalIndicators';

interface TechnicalIndicatorsProps {
  selectedStock: string;
}

export function TechnicalIndicators({ selectedStock }: TechnicalIndicatorsProps) {
  const { indicators, isLoading } = useTechnicalIndicators(selectedStock);

  if (isLoading) {
    return (
      <div className="bg-white rounded-lg border border-slate-200 p-4 animate-pulse">
        <div className="h-6 bg-slate-200 rounded w-32 mb-4" />
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="space-y-2">
              <div className="h-4 bg-slate-200 rounded w-20" />
              <div className="h-6 bg-slate-200 rounded w-16" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  const getSignalColor = (signal: string) => {
    switch (signal) {
      case 'BUY': return 'text-green-600 bg-green-100';
      case 'SELL': return 'text-red-600 bg-red-100';
      default: return 'text-yellow-600 bg-yellow-100';
    }
  };

  return (
    <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
      <div className="p-4 border-b border-slate-200">
        <div className="flex items-center space-x-2">
          <Activity className="w-5 h-5 text-purple-600" />
          <h3 className="text-lg font-semibold text-slate-900">Technical Indicators</h3>
        </div>
      </div>
      
      <div className="p-4 space-y-4">
        {/* RSI */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-slate-700">RSI (14)</span>
            <span className={`px-2 py-1 text-xs rounded-full ${getSignalColor(indicators.rsi.signal)}`}>
              {indicators.rsi.signal}
            </span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="flex-1 bg-slate-200 rounded-full h-2">
              <div 
                className={`h-2 rounded-full ${
                  indicators.rsi.value > 70 ? 'bg-red-500' : 
                  indicators.rsi.value < 30 ? 'bg-green-500' : 'bg-blue-500'
                }`}
                style={{ width: `${indicators.rsi.value}%` }}
              />
            </div>
            <span className="text-sm font-medium text-slate-900">
              {indicators.rsi.value.toFixed(1)}
            </span>
          </div>
        </div>

        {/* MACD */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-slate-700">MACD</span>
            <span className={`px-2 py-1 text-xs rounded-full ${getSignalColor(indicators.macd.signal)}`}>
              {indicators.macd.signal}
            </span>
          </div>
          <div className="text-sm text-slate-600">
            <div>MACD: {indicators.macd.macd.toFixed(2)}</div>
            <div>Signal: {indicators.macd.signal_line.toFixed(2)}</div>
            <div>Histogram: {indicators.macd.histogram.toFixed(2)}</div>
          </div>
        </div>

        {/* Bollinger Bands */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-slate-700">Bollinger Bands</span>
            <span className={`px-2 py-1 text-xs rounded-full ${getSignalColor(indicators.bollinger.signal)}`}>
              {indicators.bollinger.signal}
            </span>
          </div>
          <div className="text-sm text-slate-600">
            <div>Upper: ₹{indicators.bollinger.upper.toFixed(2)}</div>
            <div>Middle: ₹{indicators.bollinger.middle.toFixed(2)}</div>
            <div>Lower: ₹{indicators.bollinger.lower.toFixed(2)}</div>
          </div>
        </div>

        {/* Moving Averages */}
        <div className="space-y-2">
          <span className="text-sm font-medium text-slate-700">Moving Averages</span>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div className="text-slate-600">
              <div>SMA 20: ₹{indicators.sma20.toFixed(2)}</div>
              <div>SMA 50: ₹{indicators.sma50.toFixed(2)}</div>
            </div>
            <div className="text-slate-600">
              <div>EMA 20: ₹{indicators.ema20.toFixed(2)}</div>
              <div>EMA 50: ₹{indicators.ema50.toFixed(2)}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}