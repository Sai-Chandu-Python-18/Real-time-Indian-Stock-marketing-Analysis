import React, { useState } from 'react';
import { Eye, EyeOff, Lock } from 'lucide-react';

interface PasswordInputProps {
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
}

export function PasswordInput({ value, onChange, placeholder }: PasswordInputProps) {
  const [showPassword, setShowPassword] = useState(false);

  return (
    <div className="bg-white rounded-lg border border-slate-200">
      <div className="p-4 border-b border-slate-200">
        <div className="flex items-center space-x-2">
          <Lock className="w-4 h-4 text-slate-600" />
          <h3 className="font-medium text-slate-900">Encryption Password</h3>
        </div>
        <p className="text-sm text-slate-600 mt-1">
          Strong password required for AES-256 encryption
        </p>
      </div>
      
      <div className="p-4">
        <div className="relative">
          <input
            type={showPassword ? 'text' : 'password'}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder={placeholder}
            className="w-full px-4 py-3 pr-12 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors duration-200"
          />
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors duration-200"
          >
            {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
          </button>
        </div>
        
        {value && (
          <div className="mt-2 text-xs">
            <div className="flex space-x-2">
              <span className={`px-2 py-1 rounded text-xs ${
                value.length >= 8 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
              }`}>
                {value.length >= 8 ? '✓' : '✗'} 8+ characters
              </span>
              <span className={`px-2 py-1 rounded text-xs ${
                /[A-Z]/.test(value) ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-600'
              }`}>
                {/[A-Z]/.test(value) ? '✓' : '○'} Uppercase
              </span>
              <span className={`px-2 py-1 rounded text-xs ${
                /[0-9]/.test(value) ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-600'
              }`}>
                {/[0-9]/.test(value) ? '✓' : '○'} Number
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}