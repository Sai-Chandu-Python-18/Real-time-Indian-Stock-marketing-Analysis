import React from 'react';
import { StockChart } from './StockChart';
import { TechnicalIndicators } from './TechnicalIndicators';
import { VolumeAnalysis } from './VolumeAnalysis';
import { StockMetrics } from './StockMetrics';

interface DashboardProps {
  selectedStock: string;
}

export function Dashboard({ selectedStock }: DashboardProps) {
  return (
    <div className="space-y-6">
      {/* Stock Metrics */}
      <StockMetrics selectedStock={selectedStock} />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Chart */}
        <div className="lg:col-span-2">
          <StockChart selectedStock={selectedStock} />
        </div>
        
        {/* Technical Indicators */}
        <div>
          <TechnicalIndicators selectedStock={selectedStock} />
        </div>
      </div>
      
      {/* Volume Analysis */}
      <VolumeAnalysis selectedStock={selectedStock} />
    </div>
  );
}