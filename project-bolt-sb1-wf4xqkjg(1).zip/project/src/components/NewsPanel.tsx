import React, { useState } from 'react';
import { Newspaper, TrendingUp, TrendingDown, Clock, ExternalLink } from 'lucide-react';
import { motion } from 'framer-motion';
import { useNewsData } from '../hooks/useNewsData';

interface NewsPanelProps {
  selectedStock: string;
}

export function NewsPanel({ selectedStock }: NewsPanelProps) {
  const [filter, setFilter] = useState<'all' | 'positive' | 'negative' | 'neutral'>('all');
  const { news, isLoading } = useNewsData(selectedStock);

  const filteredNews = news.filter(item => {
    if (filter === 'all') return true;
    return item.sentiment === filter;
  });

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'positive': return 'text-green-600 bg-green-100';
      case 'negative': return 'text-red-600 bg-red-100';
      default: return 'text-slate-600 bg-slate-100';
    }
  };

  const getSentimentIcon = (sentiment: string) => {
    switch (sentiment) {
      case 'positive': return TrendingUp;
      case 'negative': return TrendingDown;
      default: return Clock;
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="bg-white rounded-lg border border-slate-200 p-4 animate-pulse">
            <div className="flex space-x-4">
              <div className="w-16 h-16 bg-slate-200 rounded-lg" />
              <div className="flex-1 space-y-2">
                <div className="h-4 bg-slate-200 rounded w-3/4" />
                <div className="h-3 bg-slate-200 rounded w-1/2" />
                <div className="h-3 bg-slate-200 rounded w-1/4" />
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Newspaper className="w-6 h-6 text-purple-600" />
          <h2 className="text-2xl font-bold text-slate-900">Market News</h2>
          <span className="text-sm text-slate-600">for {selectedStock}</span>
        </div>
        
        <div className="flex space-x-1 bg-slate-100 rounded-lg p-1">
          {['all', 'positive', 'negative', 'neutral'].map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f as any)}
              className={`px-3 py-1 text-sm rounded-md transition-colors duration-200 capitalize ${
                filter === f
                  ? 'bg-white text-purple-600 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* News List */}
      <div className="space-y-4">
        {filteredNews.map((item, index) => {
          const SentimentIcon = getSentimentIcon(item.sentiment);
          
          return (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-lg border border-slate-200 p-4 hover:shadow-md transition-shadow duration-200"
            >
              <div className="flex space-x-4">
                {item.image && (
                  <img 
                    src={item.image} 
                    alt="" 
                    className="w-16 h-16 object-cover rounded-lg bg-slate-100"
                  />
                )}
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-medium text-slate-900 line-clamp-2">
                      {item.title}
                    </h3>
                    <div className={`ml-2 px-2 py-1 text-xs rounded-full flex items-center space-x-1 ${getSentimentColor(item.sentiment)}`}>
                      <SentimentIcon className="w-3 h-3" />
                      <span className="capitalize">{item.sentiment}</span>
                    </div>
                  </div>
                  
                  <p className="text-sm text-slate-600 line-clamp-2 mb-3">
                    {item.description}
                  </p>
                  
                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <div className="flex items-center space-x-4">
                      <span>{item.source}</span>
                      <span>{new Date(item.publishedAt).toLocaleDateString()}</span>
                      <span className="flex items-center space-x-1">
                        <Clock className="w-3 h-3" />
                        <span>{item.readTime} min read</span>
                      </span>
                    </div>
                    
                    <a
                      href={item.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center space-x-1 text-blue-600 hover:text-blue-700 transition-colors duration-200"
                    >
                      <span>Read more</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                </div>
              </div>
            </motion.div>
          );
        })}
        
        {filteredNews.length === 0 && (
          <div className="text-center py-12">
            <Newspaper className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-slate-900 mb-2">No news found</h3>
            <p className="text-slate-600">Try adjusting your filters or check back later</p>
          </div>
        )}
      </div>
    </div>
  );
}