import React, { useState } from 'react';
import { BarChart3, Play, Settings, TrendingUp, TrendingDown } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useBacktest } from '../hooks/useBacktest';

interface BacktestPanelProps {
  selectedStock: string;
}

export function BacktestPanel({ selectedStock }: BacktestPanelProps) {
  const [strategy, setStrategy] = useState('sma_crossover');
  const [parameters, setParameters] = useState({
    shortPeriod: 20,
    longPeriod: 50,
    startDate: '2023-01-01',
    endDate: '2024-01-01',
    initialCapital: 100000
  });
  
  const { backtestResult, isRunning, runBacktest } = useBacktest();

  const strategies = [
    { id: 'sma_crossover', name: 'SMA Crossover', description: 'Simple Moving Average crossover strategy' },
    { id: 'rsi_mean_reversion', name: 'RSI Mean Reversion', description: 'Buy oversold, sell overbought' },
    { id: 'bollinger_bands', name: 'Bollinger Bands', description: 'Trade based on price bands' },
    { id: 'macd_signal', name: 'MACD Signal', description: 'MACD line and signal line crossover' }
  ];

  const handleRunBacktest = () => {
    runBacktest(selectedStock, strategy, parameters);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-2">
        <BarChart3 className="w-6 h-6 text-green-600" />
        <h2 className="text-2xl font-bold text-slate-900">Strategy Backtesting</h2>
        <span className="text-sm text-slate-600">for {selectedStock}</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Configuration Panel */}
        <div className="lg:col-span-1 space-y-6">
          {/* Strategy Selection */}
          <div className="bg-white rounded-lg border border-slate-200 p-4">
            <h3 className="font-medium text-slate-900 mb-4 flex items-center space-x-2">
              <Settings className="w-4 h-4" />
              <span>Strategy Configuration</span>
            </h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Trading Strategy
                </label>
                <select
                  value={strategy}
                  onChange={(e) => setStrategy(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                >
                  {strategies.map((s) => (
                    <option key={s.id} value={s.id}>{s.name}</option>
                  ))}
                </select>
                <p className="text-xs text-slate-500 mt-1">
                  {strategies.find(s => s.id === strategy)?.description}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Short Period
                  </label>
                  <input
                    type="number"
                    value={parameters.shortPeriod}
                    onChange={(e) => setParameters({...parameters, shortPeriod: parseInt(e.target.value)})}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Long Period
                  </label>
                  <input
                    type="number"
                    value={parameters.longPeriod}
                    onChange={(e) => setParameters({...parameters, longPeriod: parseInt(e.target.value)})}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  Initial Capital (₹)
                </label>
                <input
                  type="number"
                  value={parameters.initialCapital}
                  onChange={(e) => setParameters({...parameters, initialCapital: parseInt(e.target.value)})}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Start Date
                  </label>
                  <input
                    type="date"
                    value={parameters.startDate}
                    onChange={(e) => setParameters({...parameters, startDate: e.target.value})}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    End Date
                  </label>
                  <input
                    type="date"
                    value={parameters.endDate}
                    onChange={(e) => setParameters({...parameters, endDate: e.target.value})}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                  />
                </div>
              </div>

              <button
                onClick={handleRunBacktest}
                disabled={isRunning}
                className="w-full bg-green-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-green-700 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
              >
                <Play className="w-4 h-4" />
                <span>{isRunning ? 'Running...' : 'Run Backtest'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Results Panel */}
        <div className="lg:col-span-2 space-y-6">
          {backtestResult ? (
            <>
              {/* Performance Metrics */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-white rounded-lg border border-slate-200 p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-slate-600">Total Return</span>
                    <TrendingUp className="w-4 h-4 text-green-600" />
                  </div>
                  <p className={`text-xl font-bold ${backtestResult.totalReturn >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {backtestResult.totalReturn >= 0 ? '+' : ''}{backtestResult.totalReturn.toFixed(2)}%
                  </p>
                </div>

                <div className="bg-white rounded-lg border border-slate-200 p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-slate-600">Sharpe Ratio</span>
                    <BarChart3 className="w-4 h-4 text-blue-600" />
                  </div>
                  <p className="text-xl font-bold text-slate-900">
                    {backtestResult.sharpeRatio.toFixed(2)}
                  </p>
                </div>

                <div className="bg-white rounded-lg border border-slate-200 p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-slate-600">Max Drawdown</span>
                    <TrendingDown className="w-4 h-4 text-red-600" />
                  </div>
                  <p className="text-xl font-bold text-red-600">
                    -{backtestResult.maxDrawdown.toFixed(2)}%
                  </p>
                </div>

                <div className="bg-white rounded-lg border border-slate-200 p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-slate-600">Win Rate</span>
                    <TrendingUp className="w-4 h-4 text-green-600" />
                  </div>
                  <p className="text-xl font-bold text-slate-900">
                    {backtestResult.winRate.toFixed(1)}%
                  </p>
                </div>
              </div>

              {/* Equity Curve */}
              <div className="bg-white rounded-lg border border-slate-200 p-4">
                <h3 className="font-medium text-slate-900 mb-4">Equity Curve</h3>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={backtestResult.equityCurve}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                      <XAxis dataKey="date" stroke="#64748b" fontSize={12} />
                      <YAxis stroke="#64748b" fontSize={12} />
                      <Tooltip 
                        contentStyle={{
                          backgroundColor: '#1e293b',
                          border: 'none',
                          borderRadius: '8px',
                          color: '#fff'
                        }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="portfolio" 
                        stroke="#10b981" 
                        strokeWidth={2}
                        dot={false}
                        name="Portfolio Value"
                      />
                      <Line 
                        type="monotone" 
                        dataKey="benchmark" 
                        stroke="#6b7280" 
                        strokeWidth={1}
                        strokeDasharray="5 5"
                        dot={false}
                        name="Buy & Hold"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </>
          ) : (
            <div className="bg-white rounded-lg border border-slate-200 p-12 text-center">
              <BarChart3 className="w-12 h-12 text-slate-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-slate-900 mb-2">No backtest results yet</h3>
              <p className="text-slate-600">Configure your strategy and click "Run Backtest" to see results</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}