import React from 'react';
import { TrendingUp, TrendingDown, Activity } from 'lucide-react';
import { motion } from 'framer-motion';

interface MarketData {
  nifty: { value: number; change: number; changePercent: number };
  sensex: { value: number; change: number; changePercent: number };
  bankNifty: { value: number; change: number; changePercent: number };
}

interface MarketOverviewProps {
  marketData: MarketData;
  isLoading: boolean;
}

export function MarketOverview({ marketData, isLoading }: MarketOverviewProps) {
  const indices = [
    { name: 'NIFTY 50', ...marketData.nifty },
    { name: 'SENSEX', ...marketData.sensex },
    { name: 'BANK NIFTY', ...marketData.bankNifty },
  ];

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {[1, 2, 3].map((i) => (
          <div key={i} className="bg-white rounded-lg border border-slate-200 p-4 animate-pulse">
            <div className="h-4 bg-slate-200 rounded w-20 mb-2" />
            <div className="h-6 bg-slate-200 rounded w-24 mb-1" />
            <div className="h-4 bg-slate-200 rounded w-16" />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
      {indices.map((index, i) => (
        <motion.div
          key={index.name}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.1 }}
          className="bg-white rounded-lg border border-slate-200 p-4 hover:shadow-md transition-shadow duration-200"
        >
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-slate-600">{index.name}</h3>
            <Activity className="w-4 h-4 text-slate-400" />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="text-2xl font-bold text-slate-900">
                {index.value.toLocaleString('en-IN')}
              </p>
              <div className={`flex items-center space-x-1 text-sm ${
                index.change >= 0 ? 'text-green-600' : 'text-red-600'
              }`}>
                {index.change >= 0 ? (
                  <TrendingUp className="w-4 h-4" />
                ) : (
                  <TrendingDown className="w-4 h-4" />
                )}
                <span>
                  {index.change >= 0 ? '+' : ''}{index.change.toFixed(2)} 
                  ({index.changePercent >= 0 ? '+' : ''}{index.changePercent.toFixed(2)}%)
                </span>
              </div>
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
}