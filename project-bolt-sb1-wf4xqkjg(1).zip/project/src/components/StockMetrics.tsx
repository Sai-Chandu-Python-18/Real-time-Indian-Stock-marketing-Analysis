import React from 'react';
import { TrendingUp, TrendingDown, Volume, DollarSign } from 'lucide-react';
import { useStockMetrics } from '../hooks/useStockMetrics';

interface StockMetricsProps {
  selectedStock: string;
}

export function StockMetrics({ selectedStock }: StockMetricsProps) {
  const { metrics, isLoading } = useStockMetrics(selectedStock);

  if (isLoading) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="bg-white rounded-lg border border-slate-200 p-4 animate-pulse">
            <div className="h-4 bg-slate-200 rounded w-16 mb-2" />
            <div className="h-6 bg-slate-200 rounded w-20 mb-1" />
            <div className="h-4 bg-slate-200 rounded w-12" />
          </div>
        ))}
      </div>
    );
  }

  const metricCards = [
    {
      label: 'Current Price',
      value: `₹${metrics.currentPrice.toFixed(2)}`,
      change: metrics.dayChange,
      changePercent: metrics.dayChangePercent,
      icon: DollarSign,
    },
    {
      label: 'Volume',
      value: `${(metrics.volume / 1000000).toFixed(2)}M`,
      change: metrics.volumeChange,
      changePercent: metrics.volumeChangePercent,
      icon: Volume,
    },
    {
      label: 'Day High',
      value: `₹${metrics.dayHigh.toFixed(2)}`,
      icon: TrendingUp,
    },
    {
      label: 'Day Low',
      value: `₹${metrics.dayLow.toFixed(2)}`,
      icon: TrendingDown,
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {metricCards.map((metric, index) => (
        <div key={index} className="bg-white rounded-lg border border-slate-200 p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-slate-600">{metric.label}</span>
            <metric.icon className="w-4 h-4 text-slate-400" />
          </div>
          
          <div className="space-y-1">
            <p className="text-xl font-bold text-slate-900">{metric.value}</p>
            
            {metric.change !== undefined && (
              <div className={`flex items-center space-x-1 text-sm ${
                metric.change >= 0 ? 'text-green-600' : 'text-red-600'
              }`}>
                {metric.change >= 0 ? (
                  <TrendingUp className="w-3 h-3" />
                ) : (
                  <TrendingDown className="w-3 h-3" />
                )}
                <span>
                  {metric.change >= 0 ? '+' : ''}{metric.change.toFixed(2)}
                  {metric.changePercent && ` (${metric.changePercent >= 0 ? '+' : ''}${metric.changePercent.toFixed(2)}%)`}
                </span>
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}