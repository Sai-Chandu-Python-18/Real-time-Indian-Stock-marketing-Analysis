import React, { useState } from 'react';
import { Bell, Plus, Trash2, TrendingUp, Volume, Newspaper } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAlerts } from '../hooks/useAlerts';
import { CreateAlertModal } from './CreateAlertModal';

export function AlertsPanel() {
  const [showCreateModal, setShowCreateModal] = useState(false);
  const { alerts, removeAlert } = useAlerts();

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'price': return TrendingUp;
      case 'volume': return Volume;
      case 'news': return Newspaper;
      default: return Bell;
    }
  };

  const getAlertColor = (type: string) => {
    switch (type) {
      case 'price': return 'text-blue-600 bg-blue-100';
      case 'volume': return 'text-green-600 bg-green-100';
      case 'news': return 'text-purple-600 bg-purple-100';
      default: return 'text-slate-600 bg-slate-100';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Bell className="w-6 h-6 text-blue-600" />
          <h2 className="text-2xl font-bold text-slate-900">Alerts</h2>
          <span className="bg-blue-100 text-blue-800 text-sm px-2 py-1 rounded-full">
            {alerts.length}
          </span>
        </div>
        
        <button
          onClick={() => setShowCreateModal(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors duration-200 flex items-center space-x-2"
        >
          <Plus className="w-4 h-4" />
          <span>Create Alert</span>
        </button>
      </div>

      {/* Alerts List */}
      <div className="space-y-4">
        <AnimatePresence>
          {alerts.map((alert) => {
            const Icon = getAlertIcon(alert.type);
            
            return (
              <motion.div
                key={alert.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="bg-white rounded-lg border border-slate-200 p-4 hover:shadow-md transition-shadow duration-200"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-3">
                    <div className={`p-2 rounded-lg ${getAlertColor(alert.type)}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    
                    <div className="flex-1">
                      <h3 className="font-medium text-slate-900">{alert.title}</h3>
                      <p className="text-sm text-slate-600 mt-1">{alert.description}</p>
                      
                      <div className="flex items-center space-x-4 mt-2 text-xs text-slate-500">
                        <span>Stock: {alert.stock}</span>
                        <span>Created: {new Date(alert.createdAt).toLocaleDateString()}</span>
                        <span className={`px-2 py-1 rounded-full ${
                          alert.isActive ? 'bg-green-100 text-green-800' : 'bg-slate-100 text-slate-600'
                        }`}>
                          {alert.isActive ? 'Active' : 'Inactive'}
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  <button
                    onClick={() => removeAlert(alert.id)}
                    className="p-2 text-slate-400 hover:text-red-600 transition-colors duration-200"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
        
        {alerts.length === 0 && (
          <div className="text-center py-12">
            <Bell className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-slate-900 mb-2">No alerts yet</h3>
            <p className="text-slate-600 mb-4">Create your first alert to get notified about market movements</p>
            <button
              onClick={() => setShowCreateModal(true)}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors duration-200"
            >
              Create Alert
            </button>
          </div>
        )}
      </div>

      {/* Create Alert Modal */}
      {showCreateModal && (
        <CreateAlertModal onClose={() => setShowCreateModal(false)} />
      )}
    </div>
  );
}